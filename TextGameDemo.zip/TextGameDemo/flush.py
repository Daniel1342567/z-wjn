import os
import time

def clear():
    os.system('cls')

for i in range(3):
    clear()
    print('loading', end='', flush=True)
    time.sleep(0.1)
    for i in range(3):
        print('.', end='', flush=True)
        time.sleep(0.1)
